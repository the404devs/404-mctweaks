# 404-mctweaks

My personal Minecraft tweaks

Features:
- Silent Nether Portals
- Removed vignette overlay

### *0.0.2 (08/12/20)*
----------------------
- Changed pack format to 6 for compatibility with 1.16.2 and later.

### *0.0.1 (05/31/20)*
----------------------
- Initial version
